# %%
import pandas as pd
import numpy as np

import ipysheet

from ipysheet import sheet, cell
# %%

# %%
from IPython import get_ipython
def VariableExplorer(ipython = get_ipython()) :
	print("var inspect")
# %%
